'''
This method returns a directed acyclic graph based on the relative bias-score
of the nodes. 
i. Currently the bias-score is just centrality-score, TODO: change bias-score
to include prior-prob/application-bias.
ii. Should not have any transitive edges
'''
def populateEdges(node_scores,detectionIndices,allSeedsDictionary):
	node_scores = np.array(node_scores);
	for seed_i in detectionIndices.keys():
		centrality_i = allSeedsDictionary[seed_i][0];
		index_i = detectionIndices[seed_i];
		for seed_j in detectionIndices.keys():
			centrality_j = allSeedsDictionary[seed_j][0];
			index_j = detectionIndices[seed_j];
			if index_i==index_j:
				continue;
			if centrality_i > centrality_j:
				edges.append((index_i,index_j));
			else:
				edges.append((index_j,index_i));
	print(edges);
	return edges;
